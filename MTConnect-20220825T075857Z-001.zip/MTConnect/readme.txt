install node js
install JDK
install MTConnect